#include <iostream>

int main() {
    int x, y;
    std::cout << "Enter two integers (x and y): ";
    std::cin >> x >> y;
    std::cout << "The remainder of " << x << " divided by " << y << " is " << x % y << std::endl;
    return 0;
}
