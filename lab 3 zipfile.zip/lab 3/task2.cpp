#include <iostream>

int main() {
    std::cout << "Hello, Class!\nWelcome to the ITC-Lab Week-03" << std::endl;
    return 0;
}
