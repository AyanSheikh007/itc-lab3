#include <iostream>
using namespace std;

int main() {
    int totalMinutes;

    cout << "Enter minutes: ";
    cin >> totalMinutes;

    int hours = totalMinutes / 60;
    int minutes = totalMinutes % 60;

    cout << hours << " hours, " << minutes << " minutes" << endl;

    return 0;
}
