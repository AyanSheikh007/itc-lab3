#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int chemistry, maths, physics, total;

    cout << "Enter Value of Chemistry: ";
    cin >> chemistry;
    cout << "Enter Value of Maths: ";
    cin >> maths;
    cout << "Enter Value of Physics: ";
    cin >> physics;

    total = chemistry + maths + physics;

    cout << setw(10) << "MATHS" << setw(15) << "CHEMISTRY" << setw(15) << "PHYSICS" << setw(15) << "TOTAL" << endl;
    cout << setw(10) << maths << setw(15) << chemistry << setw(15) << physics << setw(15) << total << endl;

    return 0;
}

