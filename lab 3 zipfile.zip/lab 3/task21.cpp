#include <iostream>
using namespace std;

int main() {
    int basicCost = 500;
    int advancedCost = 1000;
    int professionalCost = 2000;
    float discountRate = 0.15;

    int basicCourses, advancedCourses, professionalCourses;

    cout << "Enter the number of Basic courses: ";
    cin >> basicCourses;

    cout << "Enter the number of Advanced courses: ";
    cin >> advancedCourses;

    cout << "Enter the number of Professional courses: ";
    cin >> professionalCourses;

    int totalCost = (basicCourses * basicCost) + (advancedCourses * advancedCost) + (professionalCourses * professionalCost);
    float discount = totalCost * discountRate;
    float finalAmount = totalCost - discount;

    cout << "Total cost: Rs " << totalCost << endl;
    cout << "Discount: Rs " << discount << endl;
    cout << "Final amount due: Rs " << finalAmount << endl;

    return 0;
}
