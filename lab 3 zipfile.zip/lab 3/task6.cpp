#include <iostream>
using namespace std;

int main() {
    cout << "Hello, world!" << endl;
    int x = 5;
    cout << "x = " << x << endl;
    return 0;
}
