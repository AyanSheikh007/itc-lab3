#include <iostream>
using namespace std;

int main() {
    int gourmetCost = 50;
    int standardCost = 30;
    int fastCost = 20;

    int gourmetSold, standardSold, fastSold;

    cout << "Enter the number of Gourmet meals sold: ";
    cin >> gourmetSold;

    cout << "Enter the number of Standard meals sold: ";
    cin >> standardSold;

    cout << "Enter the number of Fast meals sold: ";
    cin >> fastSold;

    int totalRevenue = (gourmetSold * gourmetCost) + (standardSold * standardCost) + (fastSold * fastCost);

    cout << "Total revenue generated: Rs " << totalRevenue << endl;

    return 0;
}
