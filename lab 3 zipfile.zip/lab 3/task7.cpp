#include <iostream>
using namespace std;

int main() {
    const int numScores = 5;
    double scores[numScores];
    double sum = 0.0;

    for (int i = 0; i < numScores; ++i) {
        cout << "Enter score " << (i + 1) << ": ";
        cin >> scores[i];
        sum += scores[i];
    }

    double average = sum / numScores;
    cout << "The average test score is: " << average << endl;

    return 0;
}
