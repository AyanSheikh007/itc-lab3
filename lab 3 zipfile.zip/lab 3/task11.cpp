#include <iostream>
using namespace std;

int main() {
    float chemistry, maths, physics, total;

    cout << "Enter Chemistry score: ";
    cin >> chemistry;
    cout << "Enter Maths score: ";
    cin >> maths;
    cout << "Enter Physics score: ";
    cin >> physics;

    total = chemistry + maths + physics;

    cout << "\n----- Results -----\n";
    cout << "Chemistry: " << chemistry << endl;
    cout << "Maths: " << maths << endl;
    cout << "Physics: " << physics << endl;
    cout << "Total: " << total << endl;

    return 0;
}
