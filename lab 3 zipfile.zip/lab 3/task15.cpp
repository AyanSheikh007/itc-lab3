#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int fuel, rent, bills, total;

    cout << "Enter Value of Fuel: ";
    cin >> fuel;
    cout << "Enter Value of Rent: ";
    cin >> rent;
    cout << "Enter Value of Bills: ";
    cin >> bills;

    total = fuel + rent + bills;

    cout << "\n" << setw(10) << "FUEL:" << setw(10) << fuel << endl;
    cout << setw(10) << "RENT:" << setw(10) << rent << endl;
    cout << setw(10) << "BILLS:" << setw(10) << bills << endl;
    cout << setw(10) << "TOTAL:" << setw(10) << total << endl;

    return 0;
}





