#include <iostream>
using namespace std;

int main() {
    int totalCookies = 40;
    int servings = 10;
    int caloriesPerServing = 300;

    int caloriesPerCookie = (caloriesPerServing * servings) / totalCookies;

    int cookiesEaten;
    cout << "Enter the number of cookies you ate: ";
    cin >> cookiesEaten;

    int caloriesConsumed = cookiesEaten * caloriesPerCookie;

    cout << "Calories consumed: " << caloriesConsumed << endl;

    return 0;
}
