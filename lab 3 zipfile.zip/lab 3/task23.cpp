#include <iostream>
using namespace std;

int main() {
    const float pi = 3.14159;
    float radius, height;

    cout << "Enter the radius of the cylinder: ";
    cin >> radius;

    cout << "Enter the height of the cylinder: ";
    cin >> height;

    float volume = pi * radius * radius * height;
    float surfaceArea = 2 * pi * radius * (radius + height);

    cout << "Volume of the cylinder: " << volume << endl;
    cout << "Surface area of the cylinder: " << surfaceArea << endl;

    return 0;
}
