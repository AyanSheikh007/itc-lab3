#include <iostream>
using namespace std;

int main() {
    int gallonsOfGas = 12;
    int milesDriven = 350;

    int mpg = milesDriven / gallonsOfGas;

    cout << "Miles per gallon: " << mpg << endl;

    return 0;
}








