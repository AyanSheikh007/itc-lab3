#include <iostream>
using namespace std;

int main() {
    int priceWheat, qtyWheat, priceRice, qtyRice, priceSugar, qtySugar;
    int valueWheat, valueRice, valueSugar;

    cout << "Enter price of Wheat: ";
    cin >> priceWheat;
    cout << "Enter quantity of Wheat: ";
    cin >> qtyWheat;

    cout << "Enter price of Rice: ";
    cin >> priceRice;
    cout << "Enter quantity of Rice: ";
    cin >> qtyRice;

    cout << "Enter price of Sugar: ";
    cin >> priceSugar;
    cout << "Enter quantity of Sugar: ";
    cin >> qtySugar;

    valueWheat = priceWheat * qtyWheat;
    valueRice = priceRice * qtyRice;
    valueSugar = priceSugar * qtySugar;

    cout << "\nValue of Wheat: " << valueWheat << endl;
    cout << "Value of Rice: " << valueRice << endl;
    cout << "Value of Sugar: " << valueSugar << endl;

    return 0;
}


