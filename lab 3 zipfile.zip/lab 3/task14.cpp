#include <iostream>
using namespace std;

int main() {
    int ticketsA, ticketsB, ticketsC;
    int incomeA, incomeB, incomeC, totalIncome;

    cout << "Enter number of Class A tickets sold: ";
    cin >> ticketsA;
    cout << "Enter number of Class B tickets sold: ";
    cin >> ticketsB;
    cout << "Enter number of Class C tickets sold: ";
    cin >> ticketsC;

    incomeA = ticketsA * 15;
    incomeB = ticketsB * 12;
    incomeC = ticketsC * 9;

    totalIncome = incomeA + incomeB + incomeC;

    cout << "\nIncome from Class A tickets: Rs " << incomeA << endl;
    cout << "Income from Class B tickets: Rs " << incomeB << endl;
    cout << "Income from Class C tickets: Rs " << incomeC << endl;
    cout << "Total Income: Rs " << totalIncome << endl;

    return 0;
}




