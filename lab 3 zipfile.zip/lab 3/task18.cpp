#include <iostream>
using namespace std;

int main() {
    int input;
    cout << "Enter a number: ";
    cin >> input;

    cout << "No\tSquare\tCube" << endl;

    for (int i = input; i < input + 6; i++) {
        cout << i << "\t" << i * i << "\t" << i * i * i << endl;
    }

    return 0;
}
